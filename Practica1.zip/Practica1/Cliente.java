import java.util.Scanner;
public class Cliente extends Administrador
{
  private String Nombre;
  private String Apellido;
  private int NIT;
  public Cliente(String Nombre, String Apelido, int NIT)
  {
    this.Nombre = Nombre;
    this.Apellido= Apellido;
    this.NIT = NIT;
  }
  
}