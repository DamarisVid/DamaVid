public class Administrador extends Lista
{
  private String Nombre;
  private String CodigoAdmin;
  public Administrador(String Nombre, String CodigoAdmin)
  {
   this.Nombre = Nombre;
   this.CodigoAdmin = CodigoAdmin;
  }
}
