import java.util.ArrayList;
public abstract class Lista
{
   private ArrayList<Producto>productos= new ArrayList<Producto>();
    public Lista ()
    {
        
    }
    public void añadirProducto(Producto p)
    {
        productos.add(p);
    }
    public void mostrarProductos()
    {
        for(Producto p: productos)
        {
            String nombre = p.getNombre();
            int precio = p.getPrecio();
            String Codigo = p.getCodigo();
            System.out.println("Descripcion del Producto: " + Nombre + " " + Precio + " " + Codigo );
        }
    }
    public  void buscarProducto(String Nombre)
    {
        for (Producto p : productos)
        {
            String n = p.getNombre();
            int pe = p.getPrecio();
            String co = p.getCodigo();
            if(n == Nombre)
            {
                System.out.println("Producto disponible");
                System.out.println("Descripcion del Prducto");
                System.out.println("Nombre: "+n);
                System.out.println("Precio: "+pe);
                System.out.println("Codigo: "+co);
            }
            else
            {
                System.out.println("Producto no disponible");
            }
        }
    }
}

