public class Tienda
{

}
