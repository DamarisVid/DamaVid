public class Producto
{
    protected String Nombre;
    protected int Precio;
    protected String Codigo;
    public Producto(String nombre,int precio, String codigo)
    {
        this.Nombre= Nombre;
        this.Precio= Precio;
        this.Codigo= Codigo;
    }
    public String getNombre()
    {
        return Nombre;
    }
    public int getPrecio()
    {
        return Precio;
    }
    public String getCodigo()
    {
        return Codigo;
    }
    public void setNombre(String NewNombre)
    {
        this.Nombre = NewNombre;
  
    }
    public void setPrecio(int NewPrecio)
    {
        this.Precio = NewPrecio;
    }
    public void setCodigo(String NewCodigo)
    {
        this.Codigo = NewCodigo;
    }
}
